#set( $author = "Benoit Lapointe" )
"""$Module_title
-----------------------------

About this Project
------------------
$About_this_project

Project structure
-----------------
*$Package/*
    **$FILE_NAME**:
        $Module_title
        
About this module
-----------------
$About_this_module

File structure
--------------
*import*

*constant*

*class*
    **$Class**
        '$Class_docstring'

"""
__author__ = "$author"
__date__   = "$DATE"
__copyright__ = "Copyright $YEAR, labesoft"

__version__ = "1.0.0"


class $Class:
    """$Class_docstring"""